#define UFTP_ID		0x69
#define ANNOUNCE	1
#define REGISTER	2
#define REG_CONF	3
#define FILESEG		4
#define DONE		5
#define STATUS		6
#define DONE_CONF	7
#define ABORT		99

#define BLOCKSIZE 1400
#define PACKETSIZE (BLOCKSIZE+sizeof(struct uftp_h))
#define MAXDEST 100

#define VERSION "UFTP version 1.4 by Dennis Bush"

struct uftp_h {
  long uftp_id;
  long func;
  unsigned long tx_id;
  long seq_num;
  long section_num;
  long nak_count;
  long blsize;
  long pass;
};

struct fileinfo {
  unsigned long fsize;
  long block_total;
  long section_total;
  long open;
  struct in_addr mcast;
  struct in_addr addr_list[MAXDEST];
  char name[300];
  short rxlatency1;
  short rxlatency2;
  unsigned long hilargefsize,lolargefsize;
};

char *strfunc(int func)
{
  switch (func) {
  case ANNOUNCE:
    return "ANNOUNCE";
  case REGISTER:
    return "REGISTER";
  case REG_CONF:
    return "REG_CONF";
  case FILESEG:
    return "FILESEG";
  case DONE:
    return "DONE";
  case STATUS:
    return "STATUS";
  case DONE_CONF:
    return "DONE_CONF";
  case ABORT:
    return "ABORT";
  default:
    return "UNKNOWN";
  }
}

void head_hton(struct uftp_h *header)
{
  header->uftp_id=htonl(header->uftp_id);
  header->func=htonl(header->func);
  header->tx_id=htonl(header->tx_id);
  header->seq_num=htonl(header->seq_num);
  header->section_num=htonl(header->section_num);
  header->nak_count=htonl(header->nak_count);
  header->blsize=htonl(header->blsize);
  header->pass=htonl(header->pass);
}
 
void head_ntoh(struct uftp_h *header)
{
  header->uftp_id=ntohl(header->uftp_id);
  header->func=ntohl(header->func);
  header->tx_id=ntohl(header->tx_id);
  header->seq_num=ntohl(header->seq_num);
  header->section_num=ntohl(header->section_num);
  header->nak_count=ntohl(header->nak_count);
  header->blsize=ntohl(header->blsize);
  header->pass=ntohl(header->pass);
}
 
void info_hton(struct fileinfo *info)
{
  info->fsize=htonl(info->fsize);
  info->block_total=htonl(info->block_total);
  info->section_total=htonl(info->section_total);
  info->open=htonl(info->open);
  info->rxlatency1=htons(info->rxlatency1);
  info->rxlatency2=htons(info->rxlatency2);
  info->hilargefsize=htonl(info->hilargefsize);
  info->lolargefsize=htonl(info->lolargefsize);
}
 
void info_ntoh(struct fileinfo *info)
{
  info->fsize=ntohl(info->fsize);
  info->block_total=ntohl(info->block_total);
  info->section_total=ntohl(info->section_total);
  info->open=ntohl(info->open);
  info->rxlatency1=ntohs(info->rxlatency1);
  info->rxlatency2=ntohs(info->rxlatency2);
  info->hilargefsize=ntohl(info->hilargefsize);
  info->lolargefsize=ntohl(info->lolargefsize);
}

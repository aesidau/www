#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdio.h>
#include <fcntl.h>
#include <poll.h>
#include <netdb.h>
#include <signal.h>
#include <libgen.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#include "uftp.h"
#define MAXLIST 10
#define CLIENT_ID 0x68
#define DEF_TIMEOUT 60
#define DEF_PORT 1044
#define DEF_PUB_MULTI "230.4.4.1"
#define DEF_LOG "/tmp/uftpd.log"
#define DEF_LATENCY1 1500
#define DEF_LATENCY2 1500
#define DESTDIR "/tmp"
#define TEMPDIR ""
#define USAGE "uftpd [ -d ] [ -L logfile ] [ -T temp_dir ] [ -D dest_dir ] [ -t timeout ]\n\
	[ -p port ] [ -M pub_mcast_addr[,pub_mcast_addr...] ] -I interface\n"

struct client_mes {
  int client_id;
  long tx_id;
  int state;
};

struct list {
  long id;
  int fd;
  time_t time;
  struct in_addr multi;
} id_list[MAXLIST];

int listener,receiver,parent,file,verbose,timeout,latency1,latency2,unicast;
char tempdir[100],destdir[100],filename[100],*naklist;
unsigned long numblocks,numsections,txID;
off_t filesize;
unsigned port;
struct sockaddr_in dest;
struct in_addr m_interface;

extern char *optarg;
extern int optind;

int sigset(int sig, void (*disp)(int))
{
  // in theory, could do something with sigaction, but let's not
  return 0;
}

void cleanup()
{
  close(listener);
  close(2);
}

void gotsig(int sig)
{
  fprintf(stderr,"[%d]: Exiting on signal %d\n",getpid(),sig);
  exit(0);
}

void gotpipe(int sig)
{
  fprintf(stderr,"[%d]: Got SIGPIPE\n",getpid());
}

void client_exit()
{
  char buf[PACKETSIZE];
  struct client_mes *client;

  bzero(buf,sizeof(buf));
  client=(struct client_mes *)&(buf[0]);
  client->client_id=CLIENT_ID;
  client->tx_id=txID;
  client->state=1;
  if (send(parent,buf,sizeof(buf),0)==-1) {
    fprintf(stderr,"[%d]: ",getpid());
    perror("Error sending to server");
  }
  close(receiver);
  close(file);
  close(2);
  if (naklist!=NULL)
    free(naklist);
}

void abort_msg(int sock, struct sockaddr_in *mes_dest, long id, char errstr[])
{
  char buf[PACKETSIZE],*data;
  struct uftp_h *header;

  data=&(buf[sizeof(struct uftp_h)]);
  header=(struct uftp_h *)&(buf[0]);
  header->uftp_id=UFTP_ID;
  header->func=ABORT;
  header->tx_id=id;
  strcpy(data,errstr);
  head_hton(header);
  if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)mes_dest,sizeof(*mes_dest))==-1) {
    fprintf(stderr,"[%d]: ",getpid());
    perror("Error sending ABORT");
  }
}

int getannounce()
{
  struct uftp_h *header;
  struct fileinfo *info;
  struct client_mes *client;
  struct sockaddr_in sin;
  struct ip_mreq multi;
  struct hostent *hp;
  char buf[PACKETSIZE],*data,filepath[200];
  int option,poll_ret,addr_len,i,j,k,attempt,found,resend,spair[2];
  long buffer;
  struct pollfd fds[MAXLIST];
  time_t t;
  pid_t pid;
 
  bzero(buf,sizeof(buf));
  bzero(&dest,sizeof(dest));
  addr_len=sizeof(dest);
  header=(struct uftp_h *)&(buf[0]);
  client=(struct client_mes *)&(buf[0]);
  info=(struct fileinfo *)&(buf[sizeof(struct uftp_h)]);
  data=&(buf[sizeof(struct uftp_h)]);
  while (1) { 
    fds[0].fd=listener;
    fds[0].events=POLLIN;
    for (i=0,j=1;i<MAXLIST;i++) {
      if (id_list[i].id!=0) {
        fds[j].fd=id_list[i].fd;
        fds[j++].events=POLLIN;
      }
    }
    if ((poll_ret=poll(fds,j,-1))==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Poll failed");
      continue;
    }
    if (poll_ret==0) {
      attempt++;
      resend=1;
    } else if (fds[0].revents & (POLLERR|POLLHUP|POLLNVAL)) {
      fprintf(stderr,"[%d]: poll error on listener, revents = 0x%X, exiting\n",getpid(),fds[0].revents);
      exit(0);
    } else if (fds[0].revents & POLLIN) {
      if (recvfrom(listener,buf,sizeof(buf),0,(struct sockaddr *)&dest,&addr_len)==-1) {
        fprintf(stderr,"[%d]: ",getpid());
        perror("Error receiving in server");
        continue;
      }
      head_ntoh(header);
      if (header->uftp_id==UFTP_ID) {
        found=0;
        for (i=0;i<MAXLIST;i++) {
          if (header->tx_id==id_list[i].id) {
            found=1;
            break;
          }
        }
        if (found) continue;
        if (header->func!=ANNOUNCE) { 
          if (verbose>=2)
            fprintf(stderr,"[%d]: %s: %08X, %d, %d, %d, %d\n",getpid(),strfunc(header->func),header->tx_id,header->seq_num,header->section_num,header->nak_count,header->pass);
          continue;
        }
        info_ntoh(info);
        if (info->open==0) {
          i=0;
          found=0;
          while ((info->addr_list[i].s_addr!=0)&&(!found)) {
            if (info->addr_list[i].s_addr==m_interface.s_addr)
              found=1;
            i++;
          }
          if (!found) {
            fprintf(stderr,"[%d]: Name not in host list for id %08X\n",getpid(),header->tx_id);
            continue;
          }
        }
        if (info->mcast.s_addr==0) {
          /* unicast transfer requested, make sure we're idle */
          found=0;
          for (i=0;i<MAXLIST;i++) {
            if (id_list[i].id!=0) {
              abort_msg(listener,&dest,header->tx_id,"Can't receive unicast file while receiving other files");
              fprintf(stderr,"[%d]: Denied unicast transfer from %08X, multicast in progress\n",getpid(),header->tx_id);
              found=1;
              break;
            }
          }
          if (!found) {
            unicast=1;
          } else {
            unicast=0;
            continue;
          }
        } else {
          unicast=0;
        }
        if (unicast) {
          break;
        } else {
          if (socketpair(AF_UNIX,SOCK_STREAM,0,spair)==-1) {
            fprintf(stderr,"[%d]: ",getpid());
            perror("Couldn't open socket pair");
            continue;
          }
          if ((pid=fork())==-1) {
            fprintf(stderr,"[%d]: ",getpid());
            perror("Couldn't fork");
            close(spair[0]);
            close(spair[1]);
            continue;
          } else if (pid!=0) {
            for (i=0;i<MAXLIST;i++) {
              if (id_list[i].id==0) {
                id_list[i].id=header->tx_id;
                id_list[i].fd=spair[0];
                id_list[i].multi=info->mcast;
                close(spair[1]);
                break;
              }
            }
            if (i>=MAXLIST) {
              fprintf(stderr,"[%d]: Client list overflow, exiting\n",getpid());
              exit(0);
            } else {
              if (verbose>=1)
                fprintf(stderr,"[%d]: Client list index for %08X is %d\n",getpid(),header->tx_id,i);
            }
            continue;
          } else {
            close(listener);
            close(spair[0]);
            parent=spair[1];
            atexit(client_exit);
            break;
          }
        }
      } else {
        fprintf(stderr,"[%d]: Invalid message: not uftp packet\n",getpid());
      }
    }
    for (k=1;k<j;k++) {
      if (fds[k].revents & (POLLERR|POLLHUP|POLLNVAL)) {
        if (fds[k].revents & (POLLERR|POLLNVAL)) {
          fprintf(stderr,"[%d]: poll error on child %d, revents = 0x%X\n",getpid(),k,fds[k].revents);
        } else {
          if (verbose>=1)
            fprintf(stderr,"[%d]: client end from poll\n",getpid());
        }
        for (i=0;i<MAXLIST;i++) {
          if ((fds[k].fd==id_list[i].fd)&&(id_list[i].id!=0)) {
            id_list[i].id=0;
            close(id_list[i].fd);
            break;
          }
        }
      } else if (fds[k].revents & POLLIN) {
        if (recv(fds[k].fd,buf,sizeof(buf),0)==-1) {
          fprintf(stderr,"[%d]: ",getpid());
          perror("Error receiving from client in server");
          continue;
        }
        if (client->client_id==CLIENT_ID) {
          if (verbose>=1)
            fprintf(stderr,"[%d]: Reading client request...\n",getpid());
          for (i=0;i<MAXLIST;i++) {
            if (client->tx_id==id_list[i].id) {
              break;
            }
          }
          if (i>=MAXLIST) {
            if (verbose>=1)
              fprintf(stderr,"[%d]: Couldn't find client\n",getpid());
            continue;
          }
          if (client->state==0) {
            if (verbose>=1)
              fprintf(stderr,"[%d]: client start, id=%08X\n",getpid(),id_list[i].id);
          } else if (client->state==1) {
            if (verbose>=1)
              fprintf(stderr,"[%d]: client end\n",getpid());
            close(id_list[i].fd);
            for (i=0;i<MAXLIST;i++) {
              if (id_list[i].id==client->tx_id) {
                id_list[i].id=0;
                break;
              }
            }
          } else {
            fprintf(stderr,"[%d]: Invalid client state: %d\n",getpid(),client->state);
          }
        } else {
          fprintf(stderr,"[%d]: Invalid message: not client packet\n",getpid());
        }
      }
    }
  }
  hp=gethostbyaddr((char *)&dest.sin_addr,sizeof(struct in_addr),AF_INET);
  strcpy(filename,basename(info->name));
  if (!strcmp(tempdir,"")) {
    sprintf(filepath,"%s/%s",destdir,filename);
  } else {
    sprintf(filepath,"%s/%s",tempdir,filename);
  }
  numblocks=info->block_total;
  numsections=info->section_total;
  if (info->fsize==0) {
    filesize=(off_t)info->hilargefsize<<32;
    filesize|=info->lolargefsize;
  } else {
    filesize=info->fsize;
  }
  if (info->rxlatency1)
    latency1=info->rxlatency1;
  else
    latency1=DEF_LATENCY1;
  if (info->rxlatency2)
    latency2=info->rxlatency2;
  else
    latency2=DEF_LATENCY2;
  txID=header->tx_id;
  t=time(NULL);
  fprintf(stderr,"[%d]: Received request at %s",getpid(),ctime(&t));
  fprintf(stderr,"[%d]: Request from %s id %08X\n",getpid(),(hp)?(hp->h_name):(inet_ntoa(dest.sin_addr)),txID);
  fprintf(stderr,"[%d]: Name of file to receive: %s\n",getpid(),filename);
  if (sizeof(off_t)>4)
    fprintf(stderr,"[%d]: Bytes: %lld, Blocks: %d, Sections: %d\n",getpid(),filesize,numblocks,numsections);
  else
    fprintf(stderr,"[%d]: Bytes: %d, Blocks: %d, Sections: %d\n",getpid(),filesize,numblocks,numsections);
  fprintf(stderr,"[%d]: Using private multicast address %s\n",getpid(),inet_ntoa(info->mcast));
  if ((file=open(filepath,O_WRONLY|O_CREAT|O_TRUNC,0644))==-1) {
    /* need to rethink this error */
    fprintf(stderr,"[%d]: ",getpid());
    perror("Error opening data file");
    abort_msg(receiver,&dest,txID,"Error opening data file");
    if (unicast)
      return 0;
    else
      exit(1);
  }
  if (unicast) {
    receiver=listener;
  } else {
    sin.sin_family=AF_INET;
    sin.sin_addr.s_addr=htonl(INADDR_ANY);
    sin.sin_port=port;
    if ((receiver=socket(AF_INET,SOCK_DGRAM,0))==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Error creating socket for receiver");
      exit(1);
    }
    multi.imr_multiaddr=info->mcast;
    multi.imr_interface=m_interface;
    //if (setsockopt(receiver,IPPROTO_IP,IP_ADD_MEMBERSHIP,(char *)&multi,sizeof(multi))== -1) {
    //  perror("Error joining multicast group for receiver");
    //  exit(1);
    //}
    option=1;
    if (setsockopt(receiver,SOL_SOCKET,SO_REUSEADDR,(char *)&option,sizeof(option))==
  -1) {
      perror("Error setting reuse option");
      close(receiver);
      exit(1);
    }
    if (bind(receiver,(struct sockaddr *)&sin,sizeof(sin))==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Error binding socket for receiver");
      exit(1);
    }
    buffer=262144;
    if (setsockopt(receiver,SOL_SOCKET,SO_RCVBUF,(char *)&buffer,sizeof(buffer))== -1) {
      perror("Error setting receive buffer size");
      exit(1);
    }
    client->client_id=CLIENT_ID;
    client->tx_id=txID;
    client->state=0;
    if (send(parent,buf,sizeof(buf),0)==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Error sending to server");
      exit(1);
    }
  }
  attempt=1;
  resend=1;
  while (attempt<=5) { 
    if (resend) {
      header->uftp_id=UFTP_ID;
      header->func=REGISTER;
      header->tx_id=txID;
      head_hton(header);
      if (sendto(receiver,buf,sizeof(buf),0,(struct sockaddr *)&dest,sizeof(dest))==-1) {
        fprintf(stderr,"[%d]: ",getpid());
        perror("Error sending REGISTER");
        attempt++;
        continue;
      }
      fprintf(stderr,"[%d]: REGISTER sent\n",getpid());
      resend=0;
    }
    fds[0].fd=receiver;
    fds[0].events=POLLIN;
    if ((poll_ret=poll(fds,1,latency1))==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Poll failed");
      attempt++;
      continue;
    }
    if (poll_ret==0) {
      attempt++;
      resend=1;
    } else if (fds[0].revents & (POLLERR|POLLHUP|POLLNVAL)) {
      fprintf(stderr,"[%d]: poll error, revents = 0x%X\n",getpid(),fds[0].revents);
    } else if (fds[0].revents & POLLIN) {
      addr_len=sizeof(sin);
      if (recvfrom(receiver,buf,sizeof(buf),0,(struct sockaddr *)&sin,&addr_len)==-1) {
        fprintf(stderr,"[%d]: ",getpid());
        perror("Error receiving REG_CONF");
        continue;
      }
      head_ntoh(header);
      if (header->uftp_id!=UFTP_ID) { 
        fprintf(stderr,"[%d]: Invalid REG_CONF message: not uftp packet\n",getpid());
        continue;
      }  
      if (header->tx_id!=txID) {
        if (unicast&&(header->func==ANNOUNCE)) {
          abort_msg(receiver,&sin,header->tx_id,"Currently receiving unicast file, can't receive others until complete");
          fprintf(stderr,"[%d]: Denied transfer from %08X, unicast in progress\n",getpid(),header->tx_id);
        } else {
          fprintf(stderr,"[%d]: Invalid txID: %08X, should be %08X\n",getpid(),header->tx_id,txID);
        }
        continue;
      }
      if (header->func==ANNOUNCE) {
        continue;
      }
      if (header->func==ABORT) {
        fprintf(stderr,"[%d]: Error: Transfer aborted by server: %s\n",getpid(),data);
        close(file);
        return 0;
      }
      if (header->func!=REG_CONF) { 
        fprintf(stderr,"[%d]: Invalid REG_CONF message: wrong func: %s\n",getpid(),strfunc(header->func));
        continue;
      }  
      if (info->addr_list[0].s_addr==m_interface.s_addr) {
        fprintf(stderr,"[%d]: Registration confirmed\n",getpid());
        return 1;
      }
    }
  }
  if (attempt>5) {
    fprintf(stderr,"[%d]: Registration unconfirmed by server\n",getpid());
    abort_msg(receiver,&dest,txID,"Registration unconfirmed");
    close(file);
    if (unicast)
      return 0;
    else
      exit(1);
  }
  return 1;
}

int sendstatus(int pass,int section,int wait)
{
  /*return nak count for section (could be 0), -1 for done, -2 for error*/
  struct uftp_h *header;
  char buf[PACKETSIZE],*list;
  long i,l_index,n_index;
  int numnaks,attempt,done;
  int sectionoffset,blocksthissec;

  sectionoffset=BLOCKSIZE*8*(section-1);
  blocksthissec=((section<numsections)?(BLOCKSIZE*8):(numblocks%(BLOCKSIZE*8)));
  header=(struct uftp_h *)&(buf[0]);
  list=&(buf[sizeof(struct uftp_h)]);
  numnaks=0;
  bzero(buf,sizeof(buf));
  for (i=0;i<blocksthissec;i++) {
    n_index=i+sectionoffset;
    l_index=i;
    if (naklist[n_index]) {
      if (verbose>=2)
        fprintf(stderr,"[%d]: NAK for %d\n",getpid(),n_index);
      list[l_index>>3]|=(1<<(l_index&7));
      numnaks++;
    }
  }
  if (verbose>=3) {
    for (i=0;i<BLOCKSIZE*8;i++) {
      if ((section==numsections)&&(i>=numblocks%(BLOCKSIZE*8))) {
        fprintf(stderr,"\n");
        break;
      }
      fprintf(stderr,"%d",(list[i/8] & (1<<(i%8)))!=0);
      if (i%8==7) fprintf(stderr," ");
      if (i%64==63) fprintf(stderr,"\n");
    }
  }
  done=1;
  for (i=0;i<numblocks;i++) {
    if (naklist[i]) {
      done=0;
      break;
    }
  }
  if (done&&(section==numsections)) {
    return -1;
  } else {
    if (wait&&(numnaks==1)) {
      if (section==numsections)
        n_index=numblocks-1;
      else
        n_index=BLOCKSIZE*8*section-1;
      if (naklist[n_index]) {
        /*wait for last packet*/
        return -3;
      }
    }
    header->uftp_id=UFTP_ID;
    header->func=STATUS;
    header->tx_id=txID;
    header->nak_count=numnaks;
    header->section_num=section;
    header->pass=pass;
    head_hton(header);
    if (sendto(receiver,buf,sizeof(buf),0,(struct sockaddr *)&dest,sizeof(dest))==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Error sending STATUS");
      return -2;
    }
    return numnaks;
  }
}

int getfileseg()
{
  struct pollfd fds[1];
  struct uftp_h *header;
  struct fileinfo *info;
  struct sockaddr_in sin;
  char buf[PACKETSIZE],*data;
  int i,done,wait,addr_len;
  long nak_count,last;
  off_t prev_offset,offset,ret_val;

  header=(struct uftp_h *)&(buf[0]);
  info=(struct fileinfo *)&(buf[sizeof(struct uftp_h)]);
  data=&(buf[sizeof(struct uftp_h)]);
  naklist=(char *)malloc(numblocks);
  for (i=0;i<numblocks;i++)
    naklist[i]=1;
  fds[0].fd=receiver;
  fds[0].events=POLLIN;
  done=0;
  wait=1;
  last=-1;
  prev_offset=0;
  timeout*=1000;
  lseek(file,0,SEEK_SET);
  while (!done) {
    if ((ret_val=poll(fds,1,timeout))==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Poll failed");
      continue;
    }
    if (ret_val==0) {
      fprintf(stderr,"[%d]: Transfer timed out\n",getpid());
      abort_msg(receiver,&dest,txID,"Transfer timed out");
      free(naklist);
      if (unicast)
        return 0;
      else
        exit(1);
    }
    if (fds[0].revents & (POLLERR|POLLHUP|POLLNVAL)) {
      fprintf(stderr,"[%d]: poll error, revents = 0x%X\n",getpid(),fds[0].revents);
      continue;
    }
    if (fds[0].revents & POLLIN) {
      bzero(buf,sizeof(buf));
      addr_len=sizeof(sin);
      if (recvfrom(receiver,buf,sizeof(buf),0,(struct sockaddr *)&sin,&addr_len)!=PACKETSIZE) {
        fprintf(stderr,"[%d]: ",getpid());
        perror("Error receiving FILESEG");
        continue;
      }
    } else {
      fprintf(stderr,"[%d]: unknown poll return\n",getpid());
      continue;
    }
    head_ntoh(header);
    if (header->uftp_id!=UFTP_ID) { 
      fprintf(stderr,"[%d]: error receiving file: not uftp packet\n",getpid());
      continue;
    }
    if (header->tx_id!=txID) {
      if (unicast&&(header->func==ANNOUNCE)) {
        abort_msg(receiver,&sin,header->tx_id,"Currently receiving unicast file, can't receive others until complete");
        fprintf(stderr,"[%d]: Denied transfer from %08X, unicast in progress\n",getpid(),header->tx_id);
      } else {
        fprintf(stderr,"[%d]: Invalid txID: %08X, should be %08X\n",getpid(),header->tx_id,txID);
      }
      continue;
    }
    if (header->func==FILESEG) { 
      if (verbose>=2) {
        if (header->pass!=1)
          fprintf(stderr,"[%d]: Got packet %d\n",getpid(),header->seq_num);
      } else if (verbose==1) {
        if (header->seq_num!=last+1)
          fprintf(stderr,"[%d]: Got packet %d, last was %d\n",getpid(),header->seq_num,last);
        last=header->seq_num;
      }
      offset=(off_t)header->seq_num*BLOCKSIZE;
      if ((ret_val=lseek(file,offset-prev_offset,SEEK_CUR))==-1) {
        fprintf(stderr,"[%d]: ",getpid());
        perror("lseek failed for file");
      }
      if (ret_val!=offset) {
        if (sizeof(off_t)>4)
          fprintf(stderr,"[%d]: offset is %lld, should be %lld\n",getpid(),ret_val,offset);
        else
          fprintf(stderr,"[%d]: offset is %d, should be %d\n",getpid(),ret_val,offset);
        continue;
      }
      if ((header->blsize!=BLOCKSIZE)&&(header->seq_num!=numblocks-1)) {
        fprintf(stderr,"[%d]: Bad block size: %d\n",getpid(),header->blsize);
        continue;
      }
      if ((ret_val=write(file,data,header->blsize))==-1) {
        fprintf(stderr,"[%d]: Write failed for segment %d\n",getpid(),header->seq_num);
        continue;
      }
      prev_offset=offset+ret_val;
      if (ret_val!=header->blsize) {
        fprintf(stderr,"[%d]: Write failed for segment %d, only wrote %d bytes\n",getpid(),header->seq_num,ret_val);
        continue;
      }
      naklist[header->seq_num]=0;
    } else if (header->func==DONE) { 
      fprintf(stderr,"[%d]: Got DONE message for pass %d section %d\n",getpid(),header->pass,header->section_num);
      i=0;
      while (info->addr_list[i].s_addr!=0) {
        if (info->addr_list[i].s_addr==m_interface.s_addr) {
          if ((nak_count=sendstatus(header->pass,header->section_num,wait))==-2) {
            fprintf(stderr,"[%d]: Error sending NAKs",getpid());
            wait=1;
          } else if (nak_count==-3) {
            fprintf(stderr,"[%d]: Waiting for last packet in section...\n",getpid());
            wait=0;
          } else if (nak_count==-1) {
            fprintf(stderr,"[%d]: File transfer complete\n",getpid());
            done=1;
          } else {
            fprintf(stderr,"[%d]: Sent %d NAKs for pass %d section %d\n",getpid(),nak_count,header->pass,header->section_num);
          }
          break;
        }
        i++;
      }
    } else if (header->func==ABORT) { 
      fprintf(stderr,"[%d]: Error: Transfer aborted by server: %s\n",getpid(),data);
      free(naklist);
      if (unicast)
        return 0;
      else
        exit(1);
    } else if ((header->func==REG_CONF)||(header->func==DONE_CONF)) {
      if (info->addr_list[0].s_addr==m_interface.s_addr) {
        fprintf(stderr,"[%d]: Error receiving file: wrong func: %s\n",getpid(),strfunc(header->func));
      }
    } else {
      fprintf(stderr,"[%d]: Error receiving file: wrong func: %s\n",getpid(),strfunc(header->func));
    }
  }
  free(naklist);
  return 1;
}

int getfile()
{
  struct sockaddr_in sin;
  struct pollfd fds[1];
  struct uftp_h *header;
  struct fileinfo *info;
  char buf[PACKETSIZE],temppath[200],destpath[200];
  int poll_ret,count,attempt,resend,addr_len;
  time_t t;

  header=(struct uftp_h *)&(buf[0]);
  info=(struct fileinfo *)&(buf[sizeof(struct uftp_h)]);
  if (!getfileseg()) {
    close(file);
    if (unicast)
      return 0;
    else
      exit(1);
  }
  close(file);
  attempt=1;
  resend=1;
  fds[0].fd=receiver;
  fds[0].events=POLLIN;
  while (attempt<=5) {
    if (resend) {
      bzero(buf,sizeof(buf));
      header->uftp_id=UFTP_ID;
      header->func=STATUS;
      header->tx_id=txID;
      header->nak_count=-1;
      fprintf(stderr,"[%d]: Getting confirmation...\n",getpid());
      head_hton(header);
      if (sendto(receiver,buf,sizeof(buf),0,(struct sockaddr *)&dest,sizeof(dest))==-1) {
        fprintf(stderr,"[%d]: ",getpid());
        perror("Error sending STATUS");
        attempt++;
        continue;
      }  
      resend=0;
    }
    if ((poll_ret=poll(fds,1,latency2))==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Poll failed");
      attempt++;
      continue;
    }
    if (poll_ret==0) {
      attempt++;
      resend=1;
    } else if (fds[0].revents & (POLLERR|POLLHUP|POLLNVAL)) {
      fprintf(stderr,"[%d]: poll error, revents = 0x%X\n",getpid(),fds[0].revents);
      attempt++;
    } else if (fds[0].revents & POLLIN) {
      addr_len=sizeof(sin);
      if (recvfrom(receiver,buf,sizeof(buf),0,(struct sockaddr *)&sin,&addr_len)==-1) {
        fprintf(stderr,"[%d]: ",getpid());
        perror("Error receiving DONE_CONF");
        attempt++;
        continue;
      }
      head_ntoh(header);
      if (header->uftp_id!=UFTP_ID) {
        fprintf(stderr,"[%d]: Invalid DONE_CONF message: not uftp packet\n",getpid());
        continue;
      } 
      if (header->tx_id!=txID) {
        if (unicast&&(header->func==ANNOUNCE)) {
          abort_msg(receiver,&sin,header->tx_id,"Currently receiving unicast file, can't receive others until complete");
          fprintf(stderr,"[%d]: Denied transfer from %08X, unicast in progress\n",getpid(),header->tx_id);
        } else {
          fprintf(stderr,"[%d]: Invalid txID: %08X, should be %08X\n",getpid(),header->tx_id,txID);
        }
        continue;
      }   
      if (header->func==DONE) {
        continue;
      }   
      if (header->func!=DONE_CONF) {
        fprintf(stderr,"[%d]: Invalid DONE_CONF message: wrong func: %s\n",getpid(),strfunc(header->func));
        continue;
      } 
      if (info->addr_list[0].s_addr==m_interface.s_addr) {
        t=time(NULL);
        fprintf(stderr,"[%d]: File transfer confirmed at %s",getpid(),ctime(&t));
        break;
      }
    } else {
      fprintf(stderr,"[%d]: unknown poll error\n",getpid());
      attempt++;
    }
  }
  if (strcmp(tempdir,"")) {
    sprintf(destpath,"%s/%s",destdir,filename);
    sprintf(temppath,"%s/%s",tempdir,filename);
    unlink(destpath);
    if (link(temppath,destpath)==-1) {
      fprintf(stderr,"[%d]: ",getpid());
      perror("Couldn't move file");
    } else {
      unlink(temppath);
    }
  }
  if (attempt>5) {
    fprintf(stderr,"[%d]: Recept unconfirmed by server\n",getpid());
    if (unicast)
      return 0;
    else
      exit(1);
  } else {
    if (unicast)
      return 0;
    else
      exit(0);
  }
}

int main(int argc, char *argv[])
{
  struct ip_mreq multi;
  struct hostent *hp;
  struct in_addr *addr;
  struct sockaddr_in sin;
  int option,debug,c,pid,fd;
  long buffer;
  char logfile[100],pub_multi[200],*p;
  char tempf1[100],tempf2[100];
  time_t t;

  bzero(&sin,sizeof(sin));
  bzero(&multi,sizeof(multi));
  strcpy(tempdir,TEMPDIR);
  strcpy(destdir,DESTDIR);
  addr=NULL;
  m_interface.s_addr=0;
  timeout=DEF_TIMEOUT;
  port=DEF_PORT;
  debug=0;
  verbose=0;
  strcpy(logfile,DEF_LOG);
  strcpy(pub_multi,DEF_PUB_MULTI);
  while ((c=getopt(argc,argv,"dv:L:I:t:p:T:D:M:"))!=EOF) {
    switch (c) {
    case 'd':
      debug=1;
      break;
    case 'v':
      verbose=atoi(optarg);
      break;
    case 'L':
      strncpy(logfile,optarg,sizeof(logfile)-1);
      break;
    case 'I':
      if ((hp=gethostbyname(optarg))==NULL) {
        fprintf(stderr,"Invalid host name: %s\n",optarg);
        exit(1);
      }
      addr=(struct in_addr *)hp->h_addr_list[0];
      m_interface=*addr;
      break;
    case 'p':
      port=atoi(optarg);
      if (port==0) {
        fprintf(stderr,"Invalid port\n");
        exit(1);
      }
      break;
    case 't':
      if ((atoi(optarg)<=0)||(atoi(optarg)>3600)) {
        fprintf(stderr,"Invalid timeout\n");
      } else {
        timeout=atoi(optarg);
      }
      break;
    case 'T':
      strncpy(tempdir,optarg,sizeof(tempdir)-1);
      break;
    case 'D':
      strncpy(destdir,optarg,sizeof(destdir)-1);
      break;
    case 'M':
      strncpy(pub_multi,optarg,sizeof(pub_multi)-1);
      break;
    case '?':
      fprintf(stderr,"Invalid option, %c\n",c);
      fprintf(stderr,USAGE);
      exit(1);
    }
  }
  if (!strcmp(tempdir,destdir)) {
    fprintf(stderr,"ERROR: temp dir and dest dir must be different\n");
    exit(1);
  } else if ((destdir[0]!='/')||((tempdir[0]!='/')&&(strcmp(tempdir,"")))) {
    fprintf(stderr,"ERROR: must specify absolute pathname for temp/dest directories\n");
    exit(1);
  } else {
    sprintf(tempf1,"%s/uftptmp1",tempdir);
    sprintf(tempf2,"%s/uftptmp2",destdir);
    if ((fd=open(tempf2,O_WRONLY|O_CREAT,0644))<0) {
      perror("couldn't write to dest directory");
      exit(1);
    }
    close(fd);
    if (strcmp(tempdir,"")) {
      if (link(tempf2,tempf1)==-1) {
        perror("couldn't link to from temp to dest directory");
        unlink(tempf2);
        exit(1);
      }
      unlink(tempf1);
    }
    unlink(tempf2);
  }
  if (m_interface.s_addr==0) {
    fprintf(stderr,USAGE);
    exit(1);
  }
  atexit(cleanup);
  sin.sin_family=AF_INET;
  sin.sin_addr.s_addr=htonl(INADDR_ANY);
  sin.sin_port=htons(port);
  if ((listener=socket(AF_INET,SOCK_DGRAM,0))==-1) {
    perror("Error creating socket for listener");
    exit(1);
  }
  p=(char *)strtok(pub_multi,",");
  while (p!=NULL) {
    multi.imr_multiaddr.s_addr=inet_addr(p);
    multi.imr_interface=m_interface;
    //if (setsockopt(listener,IPPROTO_IP,IP_ADD_MEMBERSHIP,(char *)&multi,sizeof(multi))== -1) {
    //  perror("Error joining multicast group for listener");
    //  exit(1);
    //}
    p=(char *)strtok(NULL,",");
  }
  option=1;
  if (setsockopt(listener,SOL_SOCKET,SO_REUSEADDR,(char *)&option,sizeof(option))==
-1) {
    perror("Error setting reuse option");
    close(listener);
    exit(1);
  }
  if (bind(listener,(struct sockaddr *)&sin,sizeof(sin))==-1) {
    perror("Error binding socket for listener");
    exit(1);
  }
  buffer=262144;
  if (setsockopt(listener,SOL_SOCKET,SO_RCVBUF,(char *)&buffer,sizeof(buffer))== -1) {
    perror("Error setting receive buffer size");
    exit(1);
  }
  if (!debug) {
    if ((fd=open(logfile,O_WRONLY|O_APPEND|O_CREAT,0644))==-1) {
      perror("Can't open log file");
      exit(1);
    }
    if ((pid=fork())==-1) {
      perror("Couldn't fork");
      exit(1);
    } else if (pid>0) {
      exit(0);
    }
    setsid();
    close(2);
    dup(fd);
    close(fd);
    for (fd=0;fd<30;fd++) {
      if ((fd!=2)&&(fd!=listener)) {
        close(fd);
      }
    }
    chdir("/");
    umask(0);
  }
  nice(-20);
  for (c=1;c<=17;c++)
    sigset(c,gotsig);
  sigset(SIGPIPE,gotpipe);
  sigset(SIGCHLD,SIG_IGN);
  for (c=0;c<MAXLIST;c++)
    id_list[c].id=0;
  t=time(NULL);
  fprintf(stderr,"\n[%d]: %s\n",getpid(),VERSION);
  fprintf(stderr,"[%d]: Starting daemon at %s",getpid(),ctime(&t));
  do {
    if (getannounce())
      getfile();
  } while (unicast);
  return 0;
}

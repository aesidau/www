#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <fcntl.h>
#include <poll.h>
#include <time.h>
#include <netdb.h>
#include <math.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

#include "uftp.h"
#define DEF_RATE 1000
#define DEF_WEIGHT 300
#define DEF_MIN_TIME 10
#define DEF_PORT 1044
#define DEF_PUB_MULTI "230.4.4.1"
#define DEF_PRIV_MULTI "230.5.5.x"
#define USAGE "uftp [ -U ] [ -R txrate ] [ -W txweight ] [ -m min_time ] [ -l latency_level ]\n\
	[ -t ttl ] [ -I interface ] [ -p port] [ -H host[,host...] ]\n\
	[ -M pub_multicast_addr ] [ -P priv_multicast_addr ] file\n"

struct destinfo_t {
  int done;
  struct in_addr addr;
  char name[50];
  struct timeval time;
  int naks;
} destlist[MAXDEST];

int sock,file,weight,min_time,destcount,unicast,verbose,latency_lev;
char filename[100],*naklist;
unsigned long numblocks,numsections,rate,wait,txID;
off_t filesize;
struct sockaddr_in listen_dest,receive_dest;

const int latency_lev_count=3;
int latency[][6]={
/* time in millilseconds to wait for each state (first set are defaults) */
/* first four are for transmittor, last two for receiver */
/* register, late register, status, late completion, reg_conf, done_conf */
{2500,2000,4000,2000,1500,1500},
{500,500,500,500,400,400},
{1000,1000,1500,1000,700,700},
{2500,2000,4000,2000,1500,1500}
};

extern char *optarg;
extern int optind;

void cleanup()
{
  close(sock);
  if (naklist!=NULL)
    free(naklist);
}

void abort_msg(char errstr[], struct sockaddr_in *dest)
{
  char buf[PACKETSIZE],*data;
  struct uftp_h *header;

  data=&(buf[sizeof(struct uftp_h)]);
  header=(struct uftp_h *)&(buf[0]);
  header->uftp_id=UFTP_ID;
  header->func=ABORT;
  header->tx_id=txID;
  strcpy(data,errstr);
  head_hton(header);
  if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)dest,sizeof(struct sockaddr_in))==-1) {
    perror("Error sending ABORT");
  }
}

void announce()
{
  struct sockaddr_in sin;
  struct pollfd fds[1];
  struct uftp_h *header;
  struct fileinfo *info;
  struct hostent *hp;
  char buf[PACKETSIZE],*data;
  int poll_ret,addr_len,attempt,i,isclosed,resend,gotall,found,polltime;

  header=(struct uftp_h *)&(buf[0]);
  info=(struct fileinfo *)&(buf[sizeof(struct uftp_h)]);
  data=&(buf[sizeof(struct uftp_h)]);
  isclosed=(destcount!=0);
  if (isclosed) {
    for (i=0;i<destcount;i++)
      destlist[i].done=-3;
  }
  polltime=latency[latency_lev][0];
  attempt=1;
  resend=1;
  fds[0].fd=sock;
  fds[0].events=POLLIN;
  while (attempt<=5) {
    if (resend) {
      bzero(buf,sizeof(buf));
      header->uftp_id=UFTP_ID;
      header->func=ANNOUNCE;
      header->tx_id=txID;
      info->block_total=numblocks;
      info->section_total=numsections;
      if (filesize>(off_t)0x7FFFFFFF) {
        info->fsize=0;
        info->hilargefsize=filesize >> 32;
        info->lolargefsize=filesize & 0xFFFFFFFF;
      } else {
        info->fsize=filesize;
        info->hilargefsize=0;
        info->lolargefsize=0;
      }
      info->mcast.s_addr=unicast?0:receive_dest.sin_addr.s_addr;
      info->rxlatency1=latency[latency_lev][4];
      info->rxlatency2=latency[latency_lev][5];
      if (isclosed) {
        info->open=0;
        for (i=0;i<destcount;i++)
          info->addr_list[i]=destlist[i].addr;
      } else {
        info->open=1;
      }
      strcpy(info->name,filename);
      fprintf(stderr,"sending ANNOUNCE\n");
      head_hton(header);
      info_hton(info);
      if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)&listen_dest,sizeof(listen_dest))==-1) {
        perror("Error sending ANNOUNCE");
        attempt++;
        continue;
      }
      resend=0;
    }
    if ((poll_ret=poll(fds,1,polltime))==-1) {
      perror("Poll failed");
      attempt++;
      continue;
    }
    if (poll_ret==0) {
      resend=1;
      attempt++;
    } else if (fds[0].revents & (POLLERR|POLLHUP|POLLNVAL)) {
      fprintf(stderr,"poll error, revents = 0x%X\n",fds[0].revents);
    } else if (fds[0].revents & POLLIN) {
      addr_len=sizeof(sin);
      if (recvfrom(sock,buf,sizeof(buf),0,(struct sockaddr *)&sin,&addr_len)!=PACKETSIZE) {
        perror("Error receiving REGISTER");
        attempt++;
        continue;
      }
      head_ntoh(header);
      info_ntoh(info);
      if (header->uftp_id!=UFTP_ID) {
        fprintf(stderr,"Invalid REGISTER message: not uftp packet\n");
        continue;
      }
      if (header->tx_id!=txID) {
	fprintf(stderr,"Invalid txID: %08X, should be %08X\n",header->tx_id,txID);
        abort_msg("Invalid txID",&sin);
        continue;
      }
      if (header->func==ABORT) {
        i=0;
        while (destlist[i].addr.s_addr!=sin.sin_addr.s_addr) {
          if (destlist[i].addr.s_addr==0)
            break;
          i++;
        }
        if (destlist[i].addr.s_addr==0) {
          fprintf(stderr,"Transfer aborted by %s: %s\n",inet_ntoa(sin.sin_addr),data);
        } else {
          fprintf(stderr,"Transfer aborted by %s: %s\n",destlist[i].name,data);
        }
        continue;
      } else if (header->func!=REGISTER) {
        fprintf(stderr,"Invalid REGISTER message: wrong func: %s\n",strfunc(header->func));
        abort_msg("Invalid function",&sin);
        continue;
      }
      if (isclosed) {
        gotall=1;
        found=0;
        for (i=0;i<destcount;i++) {
          if (sin.sin_addr.s_addr==destlist[i].addr.s_addr) {
            if (destlist[i].done==-3) {
              fprintf(stderr,"Received REGISTER from %s\n",destlist[i].name);
              destlist[i].done=0;
            } else {
              fprintf(stderr,"Received REGISTER+ from %s\n",destlist[i].name);
            }
            destlist[i].naks=0;
            found=1;
          } 
          gotall=(gotall&&(destlist[i].done==0));
        }
        if (!found) {
          fprintf(stderr,"Host %s not in host list\n",inet_ntoa(sin.sin_addr));
          abort_msg("Not in host list",&sin);
          continue;
        }
        if (gotall) {
          fprintf(stderr,"Late registers:\n");
          polltime=latency[latency_lev][1];
          attempt=5;
        }
      } else {
        for (i=0;i<destcount;i++) {
          if (sin.sin_addr.s_addr==destlist[i].addr.s_addr) {
            fprintf(stderr,"Received REGISTER+ from %s\n",destlist[i].name);
            i=-1;
            break;
          } 
        }
        if (i!=-1) {
          hp=gethostbyaddr((char *)&sin.sin_addr,sizeof(struct in_addr),AF_INET);
          strncpy(destlist[destcount].name,(hp)?(hp->h_name):(inet_ntoa(sin.sin_addr)),sizeof(destlist[0].name));
          destlist[destcount].addr=sin.sin_addr;
          destlist[destcount].done=0;
          fprintf(stderr,"Received REGISTER from %s\n",destlist[destcount++].name);
        }
      }
      if (verbose>=1)
        fprintf(stderr,"Sending REG_CONF for %s\n",inet_ntoa(sin.sin_addr));
      bzero(buf,sizeof(buf));
      header->uftp_id=UFTP_ID;
      header->func=REG_CONF;
      header->tx_id=txID;
      info->addr_list[0]=sin.sin_addr;
      if (!wait) usleep(wait);
      head_hton(header);
      if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)&receive_dest,sizeof(listen_dest))==-1) {
        perror("Error sending REG_CONF");
      } 
    } else {
      fprintf(stderr,"unknown poll error\n");
      attempt++;
    }
  }
  gotall=1;
  for (i=0;i<destcount;i++) {
    gotall=(gotall&&destlist[i].done);
  }
  if ((attempt>5)&&(gotall)) {
    fprintf(stderr,"Announce timed out\n");
    exit(0);
  }
}

int getnaks(int pass, int section)
{
  struct pollfd fds[1];
  struct sockaddr_in sin;
  char buf[PACKETSIZE],*list;
  struct uftp_h *header;
  struct fileinfo *info;
  int attempt,poll_ret,addr_len,i,j,l_index,n_index;
  int found,gotdest[MAXDEST],gotall,resend,numnaks,polltime;
  int sectionoffset,blocksthissec;

  sectionoffset=(BLOCKSIZE*8*(section-1));
  blocksthissec=((section<numsections)?(BLOCKSIZE*8):(numblocks%(BLOCKSIZE*8)));
  header=(struct uftp_h *)&(buf[0]);
  info=(struct fileinfo *)&(buf[sizeof(struct uftp_h)]);
  list=&(buf[sizeof(struct uftp_h)]);
  gotall=0;
  for (i=0;i<destcount;i++) {
    gotdest[i]=destlist[i].done;
  }
  for (i=0;i<blocksthissec;i++) {
    n_index=i+sectionoffset;
    naklist[n_index]=0;
  }
  polltime=latency[latency_lev][2];
  attempt=1;
  resend=1;
  fds[0].fd=sock;
  fds[0].events=POLLIN;
  if (!wait) usleep(wait);
  while ((attempt<=3)&&(!gotall)) {
    if (resend) {
      bzero(buf,sizeof(buf));
      header->uftp_id=UFTP_ID;
      header->func=DONE;
      header->tx_id=txID;
      header->pass=pass;
      header->section_num=section;
      for (i=0,j=0;i<destcount;i++) {
        if (!gotdest[i]) {
          info->addr_list[j++]=destlist[i].addr;
        }
      }
      fprintf(stderr,"sending DONE for pass %d section %d\n",pass,section);
      head_hton(header);
      if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)&receive_dest,sizeof(receive_dest))==-1) {
        perror("Error sending DONE");
        attempt++;
        continue;
      }
      resend=0;
    }
    if ((poll_ret=poll(fds,1,polltime))==-1) {
      perror("Poll failed");
      attempt++;
      continue;
    }
    if (poll_ret==0) {
      attempt++;
      resend=1;
    } else if (fds[0].revents & (POLLERR|POLLHUP|POLLNVAL)) {
      fprintf(stderr,"poll error, revents = 0x%X\n",fds[0].revents);
    } else if (fds[0].revents & POLLIN) {
      addr_len=sizeof(sin);
      if (recvfrom(sock,buf,sizeof(buf),0,(struct sockaddr *)&sin,&addr_len)!=PACKETSIZE) {
        perror("Error receiving STATUS");
        continue;
      }
      head_ntoh(header);
      if (header->uftp_id!=UFTP_ID) {
        fprintf(stderr,"Invalid STATUS message: not uftp packet\n");
        continue;
      }
      if (header->tx_id!=txID) {
	fprintf(stderr,"Invalid txID: %08X, should be %08X\n",header->tx_id,txID);
        continue;
      }
      if (header->func==ABORT) {
        for (i=0;i<destcount;i++) {
          if (destlist[i].addr.s_addr==sin.sin_addr.s_addr) {
            fprintf(stderr,"Transfer aborted by %s: %s\n",destlist[i].name,list);
            break;
          }
        }
        if (i==destcount) {
          fprintf(stderr,"Transfer aborted by unknown (%s): %s\n",inet_ntoa(sin.sin_addr),list);
          continue;
        }
        gotdest[i]=-1;
        destlist[i].done=-1;
        gotall=1;
        for (i=0;i<destcount;i++)
          gotall=(gotall&&gotdest[i]);
        continue;
      } else if (header->func!=STATUS) {
        fprintf(stderr,"Invalid STATUS message: wrong func: %s\n",strfunc(header->func));
        continue;
      }
      found=0;
      for (i=0;i<destcount;i++) {
        if (destlist[i].addr.s_addr==sin.sin_addr.s_addr) {
          if (header->nak_count==-1) {
            if (destlist[i].done!=1) {
              fprintf(stderr,"Got completion from %s\n",destlist[i].name);
            } else {
              fprintf(stderr,"Got completion+ from %s\n",destlist[i].name);
            }
            destlist[i].done=1;
            gotdest[i]=1;
            gettimeofday(&destlist[i].time,NULL);
            found=-1;
            bzero(buf,sizeof(buf));
            header->uftp_id=UFTP_ID;
            header->func=DONE_CONF;
            header->tx_id=txID;
            info->addr_list[0]=sin.sin_addr;
            if (!wait) usleep(wait);
            head_hton(header);
            if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)&receive_dest,sizeof(receive_dest))==-1) {
              perror("Error sending DONE_CONF");
            } 
          } else if (gotdest[i]==1) {
            found=-1;
          } else {
            fprintf(stderr,"Got %d NAKs for pass %d section %d from %s\n",header->nak_count,header->pass,header->section_num,destlist[i].name);
            if ((header->pass==pass)&&(header->section_num==section)) {
              gotdest[i]=1;
              destlist[i].naks+=header->nak_count;
            }
            found=1;
          }
          break;
        }
      }
      if (found==0) {
        fprintf(stderr,"Unknown address: %s\n",inet_ntoa(sin.sin_addr));
      } else if ((found!=-1)&&(header->pass==pass)&&(header->section_num==section)) {
        for (i=0;i<blocksthissec;i++) {
          n_index=i+sectionoffset;
          l_index=i;
          if ((list[l_index>>3] & (1<<(l_index&7)))!=0) {
            if (verbose>=2)
              fprintf(stderr,"Got NAK for %d\n",n_index);
            naklist[n_index]=1;
          }
        }
      }
      gotall=1;
      for (i=0;i<destcount;i++)
        gotall=(gotall&&destlist[i].done);
      if (gotall) {
        fprintf(stderr,"Late completions:\n");
        polltime=latency[latency_lev][3];
        attempt=3;
        gotall=0;
        continue;
      }
      gotall=1;
      for (i=0;i<destcount;i++)
        gotall=(gotall&&gotdest[i]);
    } else {
      fprintf(stderr,"unknown poll error\n");
      attempt++;
    }
  }
  if (attempt>3) {
    for (i=0;i<destcount;i++) {
      if (!gotdest[i]) {
        fprintf(stderr,"Couldn't get STATUS from %s\n",destlist[i].name);
        destlist[i].done=-2;
      }
    }
  }
  numnaks=0;
  for (i=0;i<blocksthissec;i++) {
    n_index=i+sectionoffset;
    if (naklist[n_index]) {
      numnaks++;
    }
  }
  return numnaks;
}

void xfer()
{
  char buf[PACKETSIZE],*data;
  struct uftp_h *header;
  long i,j,numnaks,nak_count;
  int numbytes,pass,quit,weight_time,max_time,aborted,naksthissec;
  struct timeval t1,t2,w1,w2;
  double t3;
  long avg,count,overage;
  off_t offset,prev_offset;

  bzero(buf,sizeof(buf));
  bzero(naklist,numblocks);
  header=(struct uftp_h *)&(buf[0]);
  data=&(buf[sizeof(struct uftp_h)]);
  if ((file=open(filename,O_RDONLY))==-1) {
    perror("Error opening file");
    exit(1);
  }
  if (rate==-1) {
    /* use 100Mbps for purpose of calculating weight */
    weight_time=floor(((double)weight/100)*((double)filesize/(100000/8)/1024));
    max_time=(weight_time>min_time)?weight_time:min_time;
    fprintf(stderr,"Transferring at full speed!\n");
  } else {
    weight_time=floor(((double)weight/100)*((double)filesize/(rate/8)/1024));
    max_time=(weight_time>min_time)?weight_time:min_time;
    fprintf(stderr,"Transfer rate: %d Kbps (%d KB/s)\n",rate,rate/8);
    fprintf(stderr,"Wait between packets: %d \xb5s\n",wait);
  }
  fprintf(stderr,"Maximum file transfer time: %d seconds\n",max_time);
  aborted=0;
  pass=1;
  if (!wait) usleep(wait);
  gettimeofday(&t1,NULL);
  do {
    if (aborted) break;
    avg=0; count=0;
    numnaks=0;
    overage=0;
    header->uftp_id=UFTP_ID;
    header->func=FILESEG;
    header->tx_id=txID;
    header->seq_num=-1;
    header->section_num=1;
    gettimeofday(&w1,NULL);
    fprintf(stderr,"Sending file...pass %d\n",pass);
    if (pass==1) {
      lseek(file,0,SEEK_SET);
      while ((numbytes=read(file,data,BLOCKSIZE))!=0) {
        if (w1.tv_sec-t1.tv_sec>max_time) {
          fprintf(stderr,"Max file transfer time exceeded\n");
          abort_msg("Max file transfer time exceeded",&receive_dest);
          aborted=1;
          for (i=0;i<destcount;i++) {
            if (!destlist[i].done) destlist[i].done=-1;
          }
          break;
        }
        header->blsize=numbytes;
        header->pass=pass;
        header->seq_num++;
        if (numbytes==-1) {
          fprintf(stderr,"read failed\n");
          continue;
        }
        if (wait>overage) usleep(wait-overage);
        gettimeofday(&w2,NULL);
        avg+=(w2.tv_usec-w1.tv_usec)+1000000*(w2.tv_sec-w1.tv_sec);
        count++;
        overage+=(w2.tv_usec-w1.tv_usec)+1000000*(w2.tv_sec-w1.tv_sec)-wait;
        w1=w2;
        head_hton(header);
        if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)&receive_dest,sizeof(receive_dest))==-1) {
          perror("Error sending FILESEG");
          continue;
        }
        head_ntoh(header);
        if ((header->seq_num%(BLOCKSIZE*8)==(BLOCKSIZE*8)-1)||(header->seq_num==numblocks-1)) {
          numnaks+=getnaks(header->pass=pass,header->section_num);
          quit=1;
          for (j=0;j<destcount;j++) {
            quit=(quit&&destlist[j].done);
          }
          if (quit) {
            numnaks=0;
            break;
          }
          gettimeofday(&w1,NULL);
          header->section_num++;
        }
      }
    } else {
      naksthissec=0;
      nak_count=0;
      prev_offset=0;
      lseek(file,0,SEEK_SET);
      for (i=0;i<numblocks;i++) {
        if (naklist[i]) {
          naksthissec=1;
          if (w1.tv_sec-t1.tv_sec>max_time) {
            fprintf(stderr,"Max file transfer time exceeded\n");
            abort_msg("Max file transfer time exceeded",&receive_dest);
            aborted=1;
            for (i=0;i<destcount;i++) {
              if (!destlist[i].done) destlist[i].done=-1;
            }
            break;
          }
          if (verbose>=2)
            fprintf(stderr,"Resending %d\n",i);
          nak_count++;
          if ((offset=lseek(file,((off_t)i*BLOCKSIZE)-prev_offset,SEEK_CUR))==-1) {
            perror("lseek failed for file");
            continue;
          }
          if (offset!=(off_t)i*BLOCKSIZE) {
            fprintf(stderr,"sizeof off_t = %d\n",sizeof(off_t));
            if (sizeof(off_t)>4)
              fprintf(stderr,"block %d: offset is %lld, should be %lld\n",i,offset,(off_t)i*BLOCKSIZE);
            else
              fprintf(stderr,"block %d: offset is %d, should be %d\n",i,offset,(off_t)i*BLOCKSIZE);
            continue;
          }
          if ((numbytes=read(file,data,BLOCKSIZE))==-1) {
            fprintf(stderr,"read failed\n");
            continue;
          }
          prev_offset=offset+numbytes;
          header->blsize=numbytes;
          header->pass=pass;
          header->seq_num=i;
          if (wait>overage) usleep(wait-overage);
          gettimeofday(&w2,NULL);
          avg+=(w2.tv_usec-w1.tv_usec)+1000000*(w2.tv_sec-w1.tv_sec);
          count++;
          overage+=(w2.tv_usec-w1.tv_usec)+1000000*(w2.tv_sec-w1.tv_sec)-wait;
          w1=w2;
          head_hton(header);
          if (sendto(sock,buf,sizeof(buf),0,(struct sockaddr *)&receive_dest,sizeof(receive_dest))==-1) {
            perror("Error sending FILESEG");
            continue;
          }
          head_ntoh(header);
        }
        if ((i%(BLOCKSIZE*8)==(BLOCKSIZE*8)-1)||(i==numblocks-1)) {
          if ((naksthissec)||(i==numblocks-1)) {
            numnaks+=getnaks(header->pass=pass,header->section_num);
          }
          naksthissec=0;
          quit=1;
          for (j=0;j<destcount;j++) {
            quit=(quit&&destlist[j].done);
          }
          if (quit) {
            numnaks=0;
            break;
          }
          gettimeofday(&w1,NULL);
          header->section_num++;
        }
      }
    }
    fprintf(stderr,"average wait time = %.2f \xb5s\n",(count==0)?0:(float)avg/count);
    fprintf(stderr,"Received %d distinct NAKs for pass %d\n",numnaks,pass);
    pass++;
  } while (numnaks);
  for (t2=t1,i=0;i<destcount;i++) {
    if ((destlist[i].time.tv_sec>t2.tv_sec)||((destlist[i].time.tv_sec==t2.tv_sec)&&(destlist[i].time.tv_usec>t2.tv_usec)))
      t2=destlist[i].time;
  }
  t3=t2.tv_sec+((double)t2.tv_usec/1000000);
  t3=t3-(t1.tv_sec+((double)t1.tv_usec/1000000));
  fprintf(stderr,"total elapsed time: %.3f seconds\n",t3);
  fprintf(stderr,"throuput: %.2f KB/s\n",filesize/t3/1024);
  fprintf(stderr,"Transfer status:\n"); 
  for (i=0;i<destcount;i++) {
    fprintf(stderr,"host: %-15s  status: ",destlist[i].name);
    switch (destlist[i].done) {
    case -3:
      fprintf(stderr,"Mute\n");
      break;
    case -2:
      fprintf(stderr,"Lost connection\n");
      break;
    case -1:
      fprintf(stderr,"Aborted\n");
      break;
    case 1:
      t3=destlist[i].time.tv_sec+((double)destlist[i].time.tv_usec/1000000);
      t3=t3-(t1.tv_sec+((double)t1.tv_usec/1000000));
      fprintf(stderr,"Completed   time: %7.3f seconds    NAKs: %d\n",t3,destlist[i].naks);
      break;
    default:
      fprintf(stderr,"Unknown  code: %d\n",destlist[i].done);
      break;
    }
  }
}

int main(int argc, char *argv[])
{
  struct sockaddr_in sin;
  struct stat statbuf;
  struct hostent *hp;
  struct in_addr *addr,out_addr;
  char pub_multi[20],priv_multi[20],tmp_multi[20],ttl,*p;
  unsigned port;
  time_t t;
  long buffer;
  int c;

  destcount=0;
  naklist=NULL;
  port=DEF_PORT;
  rate=DEF_RATE;
  weight=DEF_WEIGHT;
  min_time=DEF_MIN_TIME;
  latency_lev=0;
  out_addr.s_addr=htonl(INADDR_ANY);
  ttl='1';
  verbose=0;
  unicast=0;
  strcpy(pub_multi,DEF_PUB_MULTI);
  strcpy(priv_multi,DEF_PRIV_MULTI);
  while ((c=getopt(argc,argv,"Uv:R:W:m:l:t:I:p:H:M:P:")) != EOF) {
    switch (c) {
    case 'U':
      unicast=1;
      break;
    case 'v':
      verbose=atoi(optarg);
      break;
    case 'R':
      if ((atoi(optarg)==0)||(atoi(optarg)<-1))
        fprintf(stderr,"Invalid rate\n");
      else
        rate=atoi(optarg);
      break;
    case 'W':
      if ((atoi(optarg)<110)||(atoi(optarg)>10000))
        fprintf(stderr,"Invalid weight\n");
      else
        weight=atoi(optarg);
      break;
    case 'm':
      if ((atoi(optarg)<=0)||(atoi(optarg)>3600))
        fprintf(stderr,"Invalid min time\n");
      else
        min_time=atoi(optarg);
      break;
    case 'l':
      if ((atoi(optarg)<=0)||(atoi(optarg)>latency_lev_count))
        fprintf(stderr,"Invalid latency level\n");
      else
        latency_lev=atoi(optarg);
      break;
    case 't':
      ttl=optarg[0];
      break;
    case 'I':
      if ((hp=gethostbyname(optarg))==NULL) {
        fprintf(stderr,"Invalid host name: %s\n",optarg);
      } else {
        addr=(struct in_addr *)hp->h_addr_list[0];
        out_addr.s_addr=addr->s_addr;
      }
      break;
    case 'p':
      port=atoi(optarg);
      if (port==0) {
        fprintf(stderr,"Invalid port\n");
        exit(1);
      }
      break;
    case 'H':
      p=(char *)strtok(optarg,",");
      while (p!=NULL) {
        if ((hp=gethostbyname(p))==NULL) {
          fprintf(stderr,"Invalid destination host name: %s\n",p);
        } else {
          addr=(struct in_addr *)hp->h_addr_list[0];
          destlist[destcount].addr=*addr;
          strncpy(destlist[destcount].name,p,sizeof(destlist[0].name));
          destcount++;
        }
        p=(char *)strtok(NULL,",");
      }
      break;
    case 'M':
      strncpy(pub_multi,optarg,sizeof(pub_multi)-1);
      break;
    case 'P':
      strncpy(priv_multi,optarg,sizeof(priv_multi)-1);
      break;
    case '?':
      fprintf(stderr,USAGE);
      exit(1);
    }
  }  
  argc-=optind;
  argv+=optind;
  if (argc!=1) {
    fprintf(stderr,USAGE);
    exit(1);
  }
  if (unicast&&(destcount!=1)) {
    fprintf(stderr,"Must specify exactly one host for unicast\n");
    exit(1);
  }
  t=time(NULL);
  fprintf(stderr,"\n%s\n",VERSION);
  fprintf(stderr,"Starting at %s",ctime(&t));
  if ((sock=socket(AF_INET,SOCK_DGRAM,0))==-1) {
    perror("Error creating socket");
    exit(1);
  }
  atexit(cleanup);
  if (setsockopt(sock,IPPROTO_IP,IP_MULTICAST_TTL,(char *)&ttl,sizeof(ttl))== -1) {
    perror("Error setting ttl");
    close(sock);
    exit(1);
  }
  if (setsockopt(sock,IPPROTO_IP,IP_MULTICAST_IF,(char *)&out_addr,sizeof(out_addr))== -1) {
    perror("Error setting outgoing interface");
    close(sock);
    exit(1);
  }
  sin.sin_family=AF_INET;
  sin.sin_addr.s_addr=htonl(INADDR_ANY);
  sin.sin_port=0;
  if (bind(sock,(struct sockaddr *)&sin,sizeof(sin))==-1) {
    perror("Error binding socket");
    exit(1);
  }
  buffer=262144;
  if (setsockopt(sock,SOL_SOCKET,SO_RCVBUF,(char *)&buffer,sizeof(buffer))== -1) {
    perror("Error setting receive buffer size");
    exit(1);
  }
  listen_dest.sin_family=AF_INET;
  listen_dest.sin_addr.s_addr=inet_addr(pub_multi);
  listen_dest.sin_port=htons(port);
  srandom(getpid());
  while ((p=(char *)strchr(priv_multi,'x'))!=NULL) {
    bzero(tmp_multi,sizeof(tmp_multi));
    strncpy(tmp_multi,priv_multi,p-priv_multi);
    sprintf(tmp_multi,"%s%d%s",tmp_multi,random()&255,p+1);
    strcpy(priv_multi,tmp_multi);
  }
  receive_dest.sin_family=AF_INET;
  receive_dest.sin_addr.s_addr=inet_addr(priv_multi);
  receive_dest.sin_port=htons(port);
  if (unicast) {
    listen_dest.sin_addr=destlist[0].addr;
    receive_dest.sin_addr=destlist[0].addr;
  }
  strcpy(filename,argv[0]);
  if (stat(filename,&statbuf)==-1) {
    perror("Error getting file status");
    exit(1);
  }
  srandom(time(NULL));
  txID=random()&0xFFFF;
  txID<<=16;
  srandom(getpid());
  txID|=random()&0xFFFF;
  filesize=statbuf.st_size;
  if (filesize==0) {
    fprintf(stderr,"Error: cannot send empty file\n");
    exit(0);
  }
  numblocks=(filesize/BLOCKSIZE)+(filesize%BLOCKSIZE?1:0);
  numsections=(numblocks/(BLOCKSIZE*8))+(numblocks%(BLOCKSIZE*8)?1:0);
  naklist=(char *)malloc(numblocks);
  fprintf(stderr,"Name of file to send: %s\n",filename);
  if (sizeof(off_t)>4) 
    fprintf(stderr,"Bytes: %lld  Blocks: %d  Sections: %d\n",filesize,numblocks,numsections);
  else
    fprintf(stderr,"Bytes: %d  Blocks: %d  Sections: %d\n",filesize,numblocks,numsections);
  fprintf(stderr,"Using private multicast address %s  id %08X\n",inet_ntoa(receive_dest.sin_addr),txID);
  if (rate==-1) {
    wait=0;
  } else {
    wait=1000000*PACKETSIZE/((float)rate*1024/8);
  }
  announce();
  xfer();
  t=time(NULL);
  fprintf(stderr,"uftp: Finishing at %s",ctime(&t));
  return 0;
}

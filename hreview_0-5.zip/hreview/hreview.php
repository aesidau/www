<?php 
/*
Plugin Name: hReview Support for Editor
Plugin URI: http://www.aes.id.au/?page_id=28
Description: Allows the right microformat content to be easily added for reviews.
Version: 0.5
Author: Andrew Scott
Author URI: http://www.aes.id.au/
*/ 

/*  Copyright 2007-2008  Andrew Scott

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Include the ButtonSnap class and add our hooks
include('buttonsnap.php');
include('buttonsnap2.php');
add_action('init', 'hreview_plugin_init');
add_action('admin_footer', 'hreview_plugin_footer');
add_action('wp_head', 'hreview_plugin_head');
add_action('marker_css', 'hreview_plugin_css');

// Include hooks for TinyMCE plugin
add_filter('mce_plugins', 'hreview_plugin_mce');
add_filter('mce_buttons', 'hreview_plugin_mce_buttons');
add_action('tinymce_before_init', 'hreview_plugin_tinymce_init');

function hreview_plugin_init() {
  global $wp_version;
  // If v2.1 or newer, use TinyMCE plugin, otherwise use ButtonSnap
  if ( TRUE != version_compare($wp_version, '2.1.0', '>=') ) {
  	// Create a vertical divider in the WYSIWYG toolbar
  	buttonsnap_separator();

  	// Add the reviewing button
	$thisfolder = buttonsnap_dirname(__FILE__);
  	buttonsnap_jsbutton($thisfolder . '/starfull.gif', 'hReview', 
		'edInsertHReview();');
  } else
  {
  	// Add the reviewing button just to the 'Code' part of the editor
	$thisfolder = buttonsnap2_dirname(__FILE__);
  	buttonsnap2_jsbutton($thisfolder . '/starfull.gif', 'hReview', 
		'edInsertHReviewCode();');
  }
} // End hreview_plugin_init()

function hreview_plugin_mce($plugins) {
  global $wp_version;
  // If v2.1 or newer, use TinyMCE plugin, otherwise use ButtonSnap
  if ( TRUE == version_compare($wp_version, '2.1.0', '>=') ) {
    array_push($plugins, 'hreview_plugin');
  }
  return $plugins;
} // End hreview_plugin_mce()

function hreview_plugin_mce_buttons($buttons) {
  global $wp_version;
  // If v2.1 or newer, use TinyMCE plugin, otherwise use ButtonSnap
  if ( TRUE == version_compare($wp_version, '2.1.0', '>=') ) {
    array_push($buttons, 'separator');
    array_push($buttons, 'hreview_plugin');
  }
  return $buttons;
} // End hreview_plugin_mce_buttons()

function hreview_plugin_tinymce_init() {
  global $wp_version;
  // If v2.1 or newer, use TinyMCE plugin, otherwise use ButtonSnap
  if ( TRUE == version_compare($wp_version, '2.1.0', '>=') ) {
    // deal with a bug in wp-includes/js/tinymce/tiny_mce_config.php
    echo 'initArray["valid_elements"] = initArray["valid_elements"].replace(/p\/-div/,"p,-div");';
    $thisfolder = buttonsnap_dirname(__FILE__);
    echo 'tinyMCE.loadPlugin("hreview_plugin", "' . $thisfolder . '/tinymceplugin/");';
  }
} // End hreview_plugin_tinymce_init()

function hreview_plugin_footer() {
  $thisfolder = buttonsnap_dirname(__FILE__);
?><div id="hReviewInput" style="display:none; position:absolute; left:20px; top:20px; background:#f9fcfe">
<iframe src="<?php echo $thisfolder;
?>/hReviewInput.html" style="width:700px; height:450px" scrolling="no">This Plug-in doesn't work on your browser.</iframe>
</div>
<script type="text/javascript">//<![CDATA[
  var hreview_from_gui;
  function edInsertHReview() {
    document.getElementById('hReviewInput').style.display='';
    hreview_from_gui = true; /** Called from TinyMCE **/
  } // End edInsertHReview()

  function edInsertHReviewCode() {
    document.getElementById('hReviewInput').style.display='';
    hreview_from_gui = false; /** Called from Quicktags **/
  } // End edInsertHReview()

  function edInsertHReviewAbort() {
    document.getElementById('hReviewInput').style.display='none';
  } // End edInsertHReviewAbort()

  function edInsertHReviewStars(itemRating) {
    var markup = '';
    if ( itemRating ) {
      var i, stars, itemRatingValue = parseFloat(itemRating);
      markup = '<p class="myrating">My rating: <span class="rating">' + itemRating +
        '</span> stars<br />';
      stars = 0;
      for ( i = 1; i <= itemRatingValue; i++ ) {
        stars++;
        markup = markup + '<img class="hreview_image" width="20" height="20" src="<?php echo $thisfolder;
?>/starfull.gif" alt="*" />';
      } // End for
      i = parseInt(itemRatingValue);
      if ( itemRatingValue - i > 0.1 ) {
        stars++;
        markup = markup + '<img class="hreview_image" width="20" height="20" src="<?php echo $thisfolder;
?>/starhalf.gif" alt="1/2" />';
      } // End if
      for ( i = stars; i < 5; i++ ) {
        markup = markup + '<img class="hreview_image" width="20" height="20" src="<?php echo $thisfolder;
?>/starempty.gif" alt="" />';
      } // End for
      markup = markup + '</p>';
    } // End if
    return markup;
  } // End edInsertHReviewStars()

  function edInsertHReviewDone(itemName, itemURL, itemSummary, itemDescription, itemRating) {
    document.getElementById('hReviewInput').style.display='none';
    var HReviewOutput = '<div class="hreview"><h2 class="item"><span class="fn">' +
      ( itemURL ? '<a class="url" href="' + itemURL + '">' : '' ) +
      itemName +
      ( itemURL ? '</a>' : '') +
      '</span></h2>' +
      ( itemSummary ? '<span class="summary">' + itemSummary + 
        '</span>' : '' ) +
      ( itemDescription ? '<blockquote class="description">' +
        itemDescription + '</blockquote>' : '' ) +
      ( itemRating ? edInsertHReviewStars(itemRating) : '' ) +
      '</div>';
    if (hreview_from_gui)
    {
      buttonsnap_settext(HReviewOutput);
    } else
    {
      buttonsnap2_settext(HReviewOutput);
    }
  } // End edInsertHReviewDone()
//]]></script>
<?php
} // End hreview_plugin_footer()

function hreview_plugin_head() {
  $thisfolder = buttonsnap_dirname(__FILE__);
  echo '<link rel="stylesheet" type="text/css" media="screen" href="' .
    $thisfolder . '/hreview.css" />';
} // End hreview_plugin_head()

function hreview_plugin_css() {
  $thisfolder = buttonsnap_dirname(__FILE__);
  echo '@import url( ' . $thisfolder . '/hreview-editor.css );';
} // End hreview_plugin_css()

?>

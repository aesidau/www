tinyMCE.addToLang('hreview_plugin',{
insertbutton : 'hReview'
});

<?php 
/*
Plugin Name: hReview Support for Editor
Plugin URI: http://www.aes.id.au/?page_id=28
Version: 0.1
Description: Allows the right microformat content to be easily added for reviews.
Author: Andrew Scott
Author URI: http://www.aes.id.au/
*/ 

// Include the ButtonSnap class and add our hooks
include('buttonsnap.php');
add_action('init', 'hreview_plugin_init');
add_action('admin_footer', 'hreview_plugin_footer');

function hreview_plugin_init() 
{
  // Create a vertical divider in the WYSIWYG toolbar
  buttonsnap_separator();

  $thisfolder = buttonsnap_dirname(__FILE__);

  // Add the reviewing button
  buttonsnap_jsbutton($thisfolder . '/starfull.gif', 'hReview', 
    'edInsertHReview();');
} // End hreview_plugin_init()

function hreview_plugin_footer()
{ 
  $thisfolder = buttonsnap_dirname(__FILE__);
?><div id="hReviewInput" style="display:none; position:absolute; left:20px; top:20px; background:#f9fcfe">
<iframe src="<?php echo $thisfolder;
?>/hReviewInput.html" style="width:700px; height:450px" scrolling="no">This Plug-in doesn't work on your browser.</iframe>
</div>
<script type="text/javascript">//<![CDATA[
  var toolbar = document.getElementById('ed_toolbar');
  function edInsertHReview() {
    document.getElementById('hReviewInput').style.display='';
  }
  function edInsertHReviewAbort() {
    document.getElementById('hReviewInput').style.display='none';
  }
  function edInsertHReviewStars(itemRating)
  {
    var markup = '';
    if (itemRating)
    {
      var i, stars, itemRatingValue = parseFloat(itemRating);
      markup = '<p><strong>My rating: <span class="rating">' + itemRating +
        '</span> stars<br />';
      stars = 0;
      for (i = 1; i <= itemRatingValue; i++)
      {
        stars++;
        markup = markup + '<img width="20" height="20" src="<?php echo $thisfolder;
?>/starfull.gif" alt="*" />';
      }
      i = parseInt(itemRatingValue);
      if (itemRatingValue - i > 0.1)
      {
        stars++;
        markup = markup + '<img width="20" height="20" src="<?php echo $thisfolder;
?>/starhalf.gif" alt="1/2" />';
      }
      for (i = stars; i < 5; i++)
      {
        markup = markup + '<img width="20" height="20" src="<?php echo $thisfolder;
?>/starempty.gif" alt="" />';
      }
      markup = markup + '</p>';
    }
    return markup;
  }
  function edInsertHReviewDone(itemName, itemType, itemURL, itemSummary, itemDescription, itemRating) {
    document.getElementById('hReviewInput').style.display='none';
    var HReviewOutput = '<div class="hreview"><h2 class="item fn">' +
      (itemURL ? '<a class="url" href="' + itemURL + '">' : '') +
      itemName +
      (itemURL ? '</a>' : '') +
      '</h2>' +
      (itemType ? '<span class="type" style="display:none">' + itemType +
        '</span>' : '') +
      (itemSummary ? '<p class="summary"><strong>' + itemSummary + 
        '</strong></p>' : '') +
      (itemDescription ? '<blockquote class="description">' +
        itemDescription + '</blockquote>' : '') +
      (itemRating ? edInsertHReviewStars(itemRating) : '') +
      '</div>';
    buttonsnap_settext(HReviewOutput);
  }
//]]></script>
<?php
} // End hreview_plugin_footer()


?>

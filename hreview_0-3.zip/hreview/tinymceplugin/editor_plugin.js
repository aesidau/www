/* TinyMCE plugin for WordPress hReview plug-in.
   Details on creating TinyMCE plugins at
     http://wiki.moxiecode.com/index.php/TinyMCE:Creating_Plugin */

// Grab the text strings to be used by hreview TinyMCE button
tinyMCE.importPluginLanguagePack('hreview_plugin');

var TinyMCE_hreview_plugin = {
	getInfo : function() {
		return {
			longname : 'hReview Support for Editor',
			author : 'Andrew Scott',
			authorurl : 'http://www.aes.id.au/',
			infourl : 'http://www.aes.id.au/?page_id=28',
			version : "0.3"
		};
	},

	getControlHTML : function(cn) {
		switch (cn) {
			case "hreview_plugin":
				return tinyMCE.getButtonHTML(cn, 'lang_hreview_plugin_insertbutton', '{$pluginurl}/../starfull.gif', 'mce_hreview_plugin_insert');
		}

		return "";
	},

	execCommand : function(editor_id, element, command, user_interface, value) {
		switch (command) {
			case "mce_hreview_plugin_insert":
				edInsertHReview();
				return true;
		}

		return false;
	}
};

// Adds the plugin class to the list of available TinyMCE plugins
tinyMCE.addPlugin("hreview_plugin", TinyMCE_hreview_plugin);

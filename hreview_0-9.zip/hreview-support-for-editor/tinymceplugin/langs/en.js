tinyMCE.addI18n("en.hreview_plugin",{
insertbutton : 'hReview'
});
